import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

public class Attendanceproj{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        String myurl="jdbc:mysql://localhost/managatten";
            try       // TODO code application logic heretry
            {
              
            java.sql.Connection myconn = DriverManager.getConnection(myurl, "root", "");
            try
            {
            String a="select * from login";
            
            PreparedStatement mystatement=myconn .prepareStatement(a);
            ResultSet myresult=mystatement.executeQuery();

            if(myresult.next())
            {
                Entryportal obj=new Entryportal();
                obj.setVisible(true);

            }
            else
            {
                JOptionPane.showMessageDialog(null, "Running Software for first time, Create Admin Account first");
                CreateAdmin obj=new CreateAdmin();
                obj.setVisible(true);

            }

            }
                catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "Error in Query " + e.getMessage());
            }
            finally
            {
                myconn.close();
            }


            }
            catch(Exception e)
            {
                JOptionPane.showMessageDialog(null, "Error in Connection " + e.getMessage());
            }


    }
 }
