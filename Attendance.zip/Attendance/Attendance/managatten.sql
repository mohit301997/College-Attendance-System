-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 25, 2019 at 06:42 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `managatten`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `date1` date NOT NULL,
  `status` varchar(50) NOT NULL,
  `student_idstudent` int(11) NOT NULL,
  `student_subject_subjectid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`date1`, `status`, `student_idstudent`, `student_subject_subjectid`) VALUES
('2019-11-25', 'Present', 1, 103),
('2019-11-25', 'Absent', 2, 103),
('2019-11-25', 'Present', 2, 103);

-- --------------------------------------------------------

--
-- Table structure for table `dept_seq`
--

CREATE TABLE `dept_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) UNSIGNED NOT NULL,
  `cycle_option` tinyint(1) UNSIGNED NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB;

--
-- Dumping data for table `dept_seq`
--

INSERT INTO `dept_seq` (`next_not_cached_value`, `minimum_value`, `maximum_value`, `start_value`, `increment`, `cache_size`, `cycle_option`, `cycle_count`) VALUES
(1, 1, 9223372036854775806, 1, 1, 1000, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(30) NOT NULL,
  `password` varchar(30) DEFAULT NULL,
  `usertype` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `usertype`) VALUES
('admin', '12345', 'Administrator'),
('geeta1', '123', 'Teacher'),
('ram1', '123', 'Teacher'),
('seeta1', '123', 'Teacher'),
('sham1', '123', 'Teacher');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `idstudent` int(11) NOT NULL,
  `studentname` varchar(45) DEFAULT NULL,
  `dept` varchar(45) DEFAULT NULL,
  `semester` varchar(45) DEFAULT NULL,
  `subject_subjectid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`idstudent`, `studentname`, `dept`, `semester`, `subject_subjectid`) VALUES
(1, 'Akash', 'Computer', 'Third', 101),
(1, 'Akash', 'Computer', 'Third', 102),
(1, 'Akash', 'Computer', 'Third', 103),
(1, 'Akash', 'Computer', 'Third', 104),
(1, 'Akash', 'Computer', 'Third', 105),
(2, 'Vikas', 'Computer', 'Fourth', 101),
(2, 'Vikas', 'Computer', 'Fourth', 102),
(2, 'Vikas', 'Computer', 'Fourth', 103),
(2, 'Vikas', 'Computer', 'Fourth', 104),
(2, 'Vikas', 'Computer', 'Fourth', 106);

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `subjectid` int(11) NOT NULL,
  `subjectname` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subjectid`, `subjectname`) VALUES
(101, 'Data Structures'),
(102, 'Operating Systems'),
(103, 'Database Management'),
(104, 'Unix Programming'),
(105, 'System Softwares'),
(106, 'Environment & Health'),
(107, 'Wireless Networks');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `teacherid` int(11) NOT NULL,
  `teachername` varchar(45) DEFAULT NULL,
  `Login_username` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`teacherid`, `teachername`, `Login_username`) VALUES
(1, 'Ram', 'ram1'),
(2, 'Sham', 'sham1'),
(3, 'Seeta', 'seeta1'),
(4, 'Geeta', 'geeta1');

-- --------------------------------------------------------

--
-- Table structure for table `teaches`
--

CREATE TABLE `teaches` (
  `teacher_teacherid` int(11) NOT NULL,
  `subject_idsubject` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teaches`
--

INSERT INTO `teaches` (`teacher_teacherid`, `subject_idsubject`) VALUES
(1, 101),
(2, 102),
(3, 103),
(4, 104);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD KEY `fk_attendence_student1` (`student_idstudent`,`student_subject_subjectid`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`idstudent`,`subject_subjectid`),
  ADD KEY `fk_student_subject1` (`subject_subjectid`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`subjectid`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`teacherid`),
  ADD KEY `fk_teacher_Login` (`Login_username`);

--
-- Indexes for table `teaches`
--
ALTER TABLE `teaches`
  ADD PRIMARY KEY (`teacher_teacherid`,`subject_idsubject`),
  ADD KEY `fk_teacher_subject1` (`subject_idsubject`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `fk_attendence_student1` FOREIGN KEY (`student_idstudent`,`student_subject_subjectid`) REFERENCES `student` (`idstudent`, `subject_subjectid`) ON DELETE CASCADE;

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `fk_student_subject1` FOREIGN KEY (`subject_subjectid`) REFERENCES `subject` (`subjectid`) ON DELETE CASCADE;

--
-- Constraints for table `teacher`
--
ALTER TABLE `teacher`
  ADD CONSTRAINT `fk_teacher_Login` FOREIGN KEY (`Login_username`) REFERENCES `login` (`username`) ON DELETE CASCADE;

--
-- Constraints for table `teaches`
--
ALTER TABLE `teaches`
  ADD CONSTRAINT `fk_teacher_subject1` FOREIGN KEY (`subject_idsubject`) REFERENCES `subject` (`subjectid`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_teacher_teacher1` FOREIGN KEY (`teacher_teacherid`) REFERENCES `teacher` (`teacherid`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
