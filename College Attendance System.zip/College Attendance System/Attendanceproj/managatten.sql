-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 21, 2019 at 07:37 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `managatten`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `date1` date NOT NULL,
  `status` varchar(45) DEFAULT NULL,
  `student_idstudent` int(11) NOT NULL,
  `student_subject_subjectid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`date1`, `status`, `student_idstudent`, `student_subject_subjectid`) VALUES
('2019-10-12', 'Present', 2, 102),
('2019-10-13', 'Present', 2, 102),
('2019-10-14', 'Present', 2, 102),
('2019-10-15', 'Present', 2, 102),
('2019-10-16', 'Absent', 1, 102),
('2019-10-17', 'Absent', 1, 102),
('2019-10-18', 'Absent', 1, 102),
('2019-10-19', 'Present', 1, 102),
('2019-10-20', 'Present', 1, 102),
('2019-10-21', 'Present', 1, 101),
('2019-10-22', 'Present', 1, 101),
('2019-10-23', 'Present', 1, 101),
('2019-10-24', 'Present', 1, 101),
('2019-10-25', 'Present', 1, 101);

-- --------------------------------------------------------

--
-- Table structure for table `dept_seq`
--

CREATE TABLE `dept_seq` (
  `next_not_cached_value` bigint(21) NOT NULL,
  `minimum_value` bigint(21) NOT NULL,
  `maximum_value` bigint(21) NOT NULL,
  `start_value` bigint(21) NOT NULL COMMENT 'start value when sequences is created or value if RESTART is used',
  `increment` bigint(21) NOT NULL COMMENT 'increment value',
  `cache_size` bigint(21) UNSIGNED NOT NULL,
  `cycle_option` tinyint(1) UNSIGNED NOT NULL COMMENT '0 if no cycles are allowed, 1 if the sequence should begin a new cycle when maximum_value is passed',
  `cycle_count` bigint(21) NOT NULL COMMENT 'How many cycles have been done'
) ENGINE=InnoDB;

--
-- Dumping data for table `dept_seq`
--

INSERT INTO `dept_seq` (`next_not_cached_value`, `minimum_value`, `maximum_value`, `start_value`, `increment`, `cache_size`, `cycle_option`, `cycle_count`) VALUES
(1, 1, 9223372036854775806, 1, 1, 1000, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(30) NOT NULL,
  `password` varchar(30) DEFAULT NULL,
  `usertype` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `usertype`) VALUES
('admin', 'admin', 'Administrator'),
('umang', 'umang', 'Teacher'),
('user1', '12345', 'Teacher'),
('user2', '12345', 'Teacher'),
('user3', '12345', 'Teacher');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `idstudent` int(11) NOT NULL,
  `studentname` varchar(45) DEFAULT NULL,
  `dept` varchar(45) DEFAULT NULL,
  `semester` varchar(45) DEFAULT NULL,
  `subject_subjectid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`idstudent`, `studentname`, `dept`, `semester`, `subject_subjectid`) VALUES
(1, 'Arvind Kejriwal', 'Computer', 'Third', 101),
(1, 'Arvind Kejriwal', 'Computer', 'Third', 102),
(2, 'Vikas Singh', 'Computer', 'Fourth', 102),
(2, 'Vikas Singh', 'Computer', 'Fourth', 103);

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `subjectid` int(11) NOT NULL,
  `subjectname` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subjectid`, `subjectname`) VALUES
(101, 'Data Structures'),
(102, 'Operating Systems'),
(103, 'Database Management'),
(104, 'Unix Programming'),
(105, 'System Softwares'),
(106, 'Environment & Health'),
(107, 'Wireless Networks');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `teacherid` int(11) NOT NULL,
  `teachername` varchar(45) DEFAULT NULL,
  `Login_username` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`teacherid`, `teachername`, `Login_username`) VALUES
(1, 'Ashish', 'user1'),
(2, 'Pranay', 'user2'),
(3, 'Krishnan', 'user3'),
(4, 'Umang', 'umang');

-- --------------------------------------------------------

--
-- Table structure for table `teaches`
--

CREATE TABLE `teaches` (
  `teacher_teacherid` int(11) NOT NULL,
  `subject_idsubject` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teaches`
--

INSERT INTO `teaches` (`teacher_teacherid`, `subject_idsubject`) VALUES
(1, 101),
(1, 103),
(2, 102),
(2, 103),
(3, 101),
(4, 102);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`date1`),
  ADD KEY `fk_attendence_student1` (`student_idstudent`,`student_subject_subjectid`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`idstudent`,`subject_subjectid`),
  ADD KEY `fk_student_subject1` (`subject_subjectid`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`subjectid`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`teacherid`),
  ADD KEY `fk_teacher_Login` (`Login_username`);

--
-- Indexes for table `teaches`
--
ALTER TABLE `teaches`
  ADD PRIMARY KEY (`teacher_teacherid`,`subject_idsubject`),
  ADD KEY `fk_teacher_subject1` (`subject_idsubject`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `fk_attendence_student1` FOREIGN KEY (`student_idstudent`,`student_subject_subjectid`) REFERENCES `student` (`idstudent`, `subject_subjectid`) ON DELETE CASCADE;

--
-- Constraints for table `student`
--
ALTER TABLE `student`
  ADD CONSTRAINT `fk_student_subject1` FOREIGN KEY (`subject_subjectid`) REFERENCES `subject` (`subjectid`) ON DELETE CASCADE;

--
-- Constraints for table `teacher`
--
ALTER TABLE `teacher`
  ADD CONSTRAINT `fk_teacher_Login` FOREIGN KEY (`Login_username`) REFERENCES `login` (`username`) ON DELETE CASCADE;

--
-- Constraints for table `teaches`
--
ALTER TABLE `teaches`
  ADD CONSTRAINT `fk_teacher_subject1` FOREIGN KEY (`subject_idsubject`) REFERENCES `subject` (`subjectid`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_teacher_teacher1` FOREIGN KEY (`teacher_teacherid`) REFERENCES `teacher` (`teacherid`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
